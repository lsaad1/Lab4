#include <stdio.h>
int main() {
char inputstr[10];
printf("Type an input: \n");
scanf("%s",inputstr);
printf("String you entered %s", inputstr);
return 0;
}
